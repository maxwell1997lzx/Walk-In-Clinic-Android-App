package com.example.final_project;

public enum PaymentMethod {
    CREDIT,
    DEBIT,
    CASH
}
