package com.example.final_project;

public enum ServiceRole {
    Doctor,
    Nurse,
    Staff
}
